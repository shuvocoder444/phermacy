from django.utils.deprecation import MiddlewareMixin

from core.models import Tenant


class TenantMiddleware(MiddlewareMixin):
    """
    Resolves the active tenant from subdomain, session, or default store profile.
    Ensures request.tenant is always available throughout the application.
    """
    def process_request(self, request):
        host = request.get_host().split(":")[0]
        subdomain = host.split(".")[0] if "." in host else ""
         
        tenant = None
        if subdomain and subdomain not in ("www", "localhost", "127"):
            tenant = Tenant.objects.filter(slug=subdomain, is_active=True).first()
            
        if not tenant:
            # Fallback to the first active tenant or create a default demo tenant
            tenant = Tenant.objects.filter(is_active=True).first()
            
        request.tenant = tenant
