import os
import sys

# cPanel Phusion Passenger WSGI entry point
project_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_dir)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "pharmacy_saas.settings")

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()

