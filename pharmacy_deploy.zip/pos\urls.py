from django.urls import path
from . import views
from . import voice_service
from . import ocr_service

app_name = "pos"

urlpatterns = [
    path("", views.pos_screen_view, name="screen"),
    path("search/", views.drug_search_htmx, name="search"),
    path("cart/add/", views.cart_add_htmx, name="cart_add"),
    path("cart/update/", views.cart_update_quantity_htmx, name="cart_update"),
    path("cart/remove/", views.cart_remove_item_htmx, name="cart_remove"),
    path("cart/discount/", views.cart_apply_discount_htmx, name="cart_discount"),
    path("cart/clear/", views.cart_clear_htmx, name="cart_clear"),
    path("checkout/modal/", views.checkout_modal_htmx, name="checkout_modal"),
    path("checkout/submit/", views.checkout_submit_htmx, name="checkout_submit"),
    path("receipt/<uuid:invoice_id>/print/", views.print_thermal_receipt, name="print_receipt"),
    # Voice Dispensing Endpoint
    path("voice/add/", voice_service.voice_add_to_cart_htmx, name="voice_add"),
    # Camera OCR Scan Endpoint
    path("camera/scan/", ocr_service.process_camera_scan_htmx, name="camera_scan"),
]
