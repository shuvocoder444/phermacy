import json
import logging
from decimal import Decimal
from typing import List, Dict, Any, Optional
from django.core.cache import cache
from django.db.models import Q, Sum, F
from django.utils import timezone
from .models import BrandDrug, DrugBatch, GenericDrug

logger = logging.getLogger(__name__)

TOP_DRUGS_CACHE_KEY_PREFIX = "pharma:top_drugs:"
DRUG_SEARCH_CACHE_TTL = 3600  # 1 Hour


class DrugSearchAndCacheService:
    """
    High-performance caching and search service for pharmaceutical catalog.
    Maintains top 1,000 frequent drugs in Redis and executes fast fallback queries.
    """

    @classmethod
    def get_tenant_cache_key(cls, tenant_id: str) -> str:
        return f"{TOP_DRUGS_CACHE_KEY_PREFIX}{tenant_id}"

    @classmethod
    def prime_top_drugs_cache(cls, tenant_id: str, limit: int = 1000) -> List[Dict[str, Any]]:
        """
        Loads the top 1,000 active drugs with aggregated non-expired stock and batch pricing into Redis.
        """
        today = timezone.now().date()
        drugs = (
            BrandDrug.objects.filter(is_active=True)
            .select_related("generic", "manufacturer", "dosage_form")
            .prefetch_related("batches")
            .annotate(
                available_stock=Sum(
                    "batches__current_stock",
                    filter=Q(batches__current_stock__gt=0, batches__expiry_date__gt=today)
                )
            )
            .order_by("-created_at")[:limit]
        )

        catalog_data = []
        for drug in drugs:
            # Get earliest expiring batch for default selection (FEFO)
            fefo_batch = drug.batches.filter(current_stock__gt=0, expiry_date__gt=today).order_by("expiry_date").first()
            
            catalog_data.append({
                "id": str(drug.id),
                "brand_name": drug.brand_name,
                "brand_name_bn": drug.brand_name_bn or "",
                "generic_name": drug.generic.name,
                "generic_id": str(drug.generic.id),
                "strength": drug.strength,
                "dosage_form": drug.dosage_form.short_name or drug.dosage_form.name,
                "manufacturer": drug.manufacturer.name,
                "rack_location": drug.rack_location or "N/A",
                "unit_mrp": str(drug.unit_mrp),
                "unit_tp": str(drug.unit_tp),
                "vat_percent": str(drug.vat_percent),
                "total_stock": drug.available_stock or 0,
                "fefo_batch": {
                    "id": str(fefo_batch.id) if fefo_batch else None,
                    "batch_number": fefo_batch.batch_number if fefo_batch else "N/A",
                    "expiry_date": fefo_batch.expiry_date.strftime("%Y-%m-%d") if fefo_batch else "N/A",
                    "stock": fefo_batch.current_stock if fefo_batch else 0,
                } if fefo_batch else None
            })

        cache_key = cls.get_tenant_cache_key(tenant_id)
        cache.set(cache_key, catalog_data, timeout=DRUG_SEARCH_CACHE_TTL)
        logger.info(f"Primed Redis cache with {len(catalog_data)} drugs for tenant {tenant_id}")
        return catalog_data

    @classmethod
    def search_drugs(cls, query: str, tenant_id: str, limit: int = 15) -> List[Dict[str, Any]]:
        """
        Dual-mode search: checks Redis in-memory cache first; falls back to database query.
        Matches Brand Name, Generic Name, Barcode, and Bengali brand name.
        """
        query_clean = query.strip().lower()
        if not query_clean:
            return []

        cache_key = cls.get_tenant_cache_key(tenant_id)
        cached_catalog = cache.get(cache_key)

        if cached_catalog:
            # Fast in-memory scan over the top 1000 drugs
            matched = []
            for item in cached_catalog:
                if (
                    query_clean in item["brand_name"].lower()
                    or query_clean in item["generic_name"].lower()
                    or (item["brand_name_bn"] and query_clean in item["brand_name_bn"])
                ):
                    matched.append(item)
                    if len(matched) >= limit:
                        return matched
            if matched:
                return matched

        # Database Fallback (for queries outside top 1000 or cache miss)
        today = timezone.now().date()
        db_qs = (
            BrandDrug.objects.filter(
                Q(brand_name__icontains=query_clean)
                | Q(generic__name__icontains=query_clean)
                | Q(brand_name_bn__icontains=query_clean)
                | Q(barcode=query_clean),
                is_active=True
            )
            .select_related("generic", "manufacturer", "dosage_form")
            .prefetch_related("batches")
            .annotate(
                available_stock=Sum(
                    "batches__current_stock",
                    filter=Q(batches__current_stock__gt=0, batches__expiry_date__gt=today)
                )
            )[:limit]
        )

        results = []
        for drug in db_qs:
            fefo_batch = drug.batches.filter(current_stock__gt=0, expiry_date__gt=today).order_by("expiry_date").first()
            results.append({
                "id": str(drug.id),
                "brand_name": drug.brand_name,
                "brand_name_bn": drug.brand_name_bn or "",
                "generic_name": drug.generic.name,
                "generic_id": str(drug.generic.id),
                "strength": drug.strength,
                "dosage_form": drug.dosage_form.short_name or drug.dosage_form.name,
                "manufacturer": drug.manufacturer.name,
                "rack_location": drug.rack_location or "N/A",
                "unit_mrp": str(drug.unit_mrp),
                "unit_tp": str(drug.unit_tp),
                "vat_percent": str(drug.vat_percent),
                "total_stock": drug.available_stock or 0,
                "fefo_batch": {
                    "id": str(fefo_batch.id) if fefo_batch else None,
                    "batch_number": fefo_batch.batch_number if fefo_batch else "N/A",
                    "expiry_date": fefo_batch.expiry_date.strftime("%Y-%m-%d") if fefo_batch else "N/A",
                    "stock": fefo_batch.current_stock if fefo_batch else 0,
                } if fefo_batch else None
            })

        return results

