"""Pharmacy template tags."""
