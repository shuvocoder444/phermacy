import re
import base64
import logging
from io import BytesIO
from typing import List, Dict, Any, Optional
from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST, require_GET
from django.db.models import Q
from PIL import Image

from inventory.models import BrandDrug, DrugBatch
from inventory.services import DrugSearchAndCacheService
from pos.cart import POSCartManager
from pos.views import get_cart_manager

logger = logging.getLogger(__name__)


def extract_potential_medicine_names_from_text(raw_text: str) -> List[str]:
    """
    Cleans OCR extracted text, strips noise words, and finds potential drug candidates.
    """
    lines = raw_text.splitlines()
    candidates = []
    
    # Noise words to ignore
    STOP_WORDS = {
        "mfg", "lic", "dar", "no", "exp", "batch", "date", "mrp", "tk", "bdt",
        "tab", "cap", "mg", "ml", "capsule", "tablet", "pharma", "ltd", "plc",
        "price", "retail", "strip", "box", "rx", "only", "keep", "out", "reach"
    }

    for line in lines:
        cleaned = re.sub(r'[^a-zA-Z0-9\s\-\+]', ' ', line).strip()
        words = cleaned.split()
        if not words:
            continue
            
        # Collect full line or significant words
        line_clean = " ".join([w for w in words if len(w) > 2 and w.lower() not in STOP_WORDS])
        if len(line_clean) >= 3:
            candidates.append(line_clean)
        
        # Also add individual capitalized tokens
        for w in words:
            if len(w) >= 3 and w.lower() not in STOP_WORDS:
                candidates.append(w)
                
    return list(dict.fromkeys(candidates))


def match_ocr_text_to_drugs(ocr_text: str, tenant_key: str = "default_tenant", limit: int = 5) -> List[Dict[str, Any]]:
    """
    Matches text scanned from medicine packaging or prescription to our DGDA drug database.
    """
    candidates = extract_potential_medicine_names_from_text(ocr_text)
    matched_drugs = []
    seen_ids = set()

    for query in candidates:
        results = DrugSearchAndCacheService.search_drugs(query=query, tenant_id=tenant_key, limit=3)
        for drug in results:
            if drug["id"] not in seen_ids:
                seen_ids.add(drug["id"])
                matched_drugs.append(drug)
                if len(matched_drugs) >= limit:
                    return matched_drugs

    # Fallback to direct DB query with any candidate word
    if not matched_drugs:
        words = [w for w in re.sub(r'[^a-zA-Z0-9]', ' ', ocr_text).split() if len(w) >= 3]
        for w in words[:6]:
            db_drugs = BrandDrug.objects.filter(
                Q(brand_name__icontains=w) | Q(generic__name__icontains=w),
                is_active=True
            ).select_related("dosage_form", "manufacturer")[:3]

            for d in db_drugs:
                if str(d.id) not in seen_ids:
                    seen_ids.add(str(d.id))
                    fefo = d.batches.fefo().first()
                    matched_drugs.append({
                        "id": str(d.id),
                        "brand_name": d.brand_name,
                        "generic_name": d.generic.name,
                        "strength": d.strength,
                        "dosage_form": d.dosage_form.short_name or d.dosage_form.name,
                        "manufacturer": d.manufacturer.name,
                        "unit_mrp": str(d.unit_mrp),
                        "total_stock": d.total_stock,
                        "fefo_batch": {
                            "id": str(fefo.id) if fefo else None,
                            "batch_number": fefo.batch_number if fefo else "N/A",
                            "expiry_date": fefo.expiry_date.strftime("%Y-%m-%d") if fefo else "N/A",
                            "stock": fefo.current_stock if fefo else 0,
                        } if fefo else None
                    })
                    if len(matched_drugs) >= limit:
                        return matched_drugs

    return matched_drugs


@require_POST
def process_camera_scan_htmx(request):
    """
    Receives text extracted from client-side camera OCR (or server-side image payload),
    matches with DGDA database, and returns detected medicine suggestions.
    """
    extracted_text = request.POST.get("extracted_text", "").strip()
    image_data = request.POST.get("image_data", "")

    tenant_id = getattr(request, "tenant", None)
    tenant_key = str(tenant_id.id) if tenant_id and hasattr(tenant_id, "id") else "default_tenant"

    # If raw extracted text is provided
    detected_drugs = match_ocr_text_to_drugs(ocr_text=extracted_text, tenant_key=tenant_key, limit=5)

    context = {
        "detected_drugs": detected_drugs,
        "raw_text": extracted_text[:120] if extracted_text else "No text detected",
    }
    return render(request, "pos/partials/camera_scan_results.html", context)

