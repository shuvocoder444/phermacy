import re
import logging
from decimal import Decimal
from typing import Tuple, List, Dict, Any, Optional
from django.shortcuts import render
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST
from django.db.models import Q

from inventory.models import BrandDrug, DrugBatch
from inventory.services import DrugSearchAndCacheService
from pos.cart import POSCartManager
from pos.views import get_cart_manager

logger = logging.getLogger(__name__)

# Phonetic & Transliteration dictionary for common Bengali medicine pronunciation
BANGLA_TO_ENG_PHONETIC = {
    "নাপা": "Napa",
    "নাপা এক্সট্রা": "Napa Extra",
    "নাপা রেপিড": "Napa Rapid",
    "নাপা র‍্যাপিড": "Napa Rapid",
    "নাপা সিরাপ": "Napa Syrup",
    "এইস": "Ace",
    "এইস প্লাস": "Ace Plus",
    "সারজেল": "Sergel",
    "সারজেল ২০": "Sergel 20",
    "সারজেল ৪০": "Sergel 40",
    "ম্যাক্সপ্রো": "Maxpro",
    "ম্যাক্সপ্রো ২০": "Maxpro 20",
    "ম্যাক্সপ্রো ৪০": "Maxpro 40",
    "সেকলো": "Seclo",
    "প্যান্টোনিক্স": "Pantonix",
    "ফিনিক্স": "Finix",
    "সেফ ৩": "Cef-3",
    "সেফ-৩": "Cef-3",
    "সেফ থ্রি": "Cef-3",
    "জিম্যাক্স": "Zimax",
    "মক্সাক্ল্যাভ": "Moxaclav",
    "সিপ্রোসিন": "Ciprocin",
    "ফ্লামিড": "Flamyd",
    "মোনাস": "Monas",
    "মোনাস ১০": "Monas 10",
    "মন্টিন": "Montene",
    "ফেক্সো": "Fexo",
    "ফেক্সো ১২০": "Fexo 120",
    "ফেক্সো ১৮০": "Fexo 180",
    "বিলাটিন": "Bilatin",
    "অ্যালাট্রোল": "Alatrol",
    "হিস্টাসিন": "Histacin",
    "টাসকা": "Tusca",
    "আদভাস": "Adovas",
    "উইন্ডেল": "Windel",
    "কম্প্যাথ": "Compath",
    "জি মেট": "G-Met",
    "বাইসলল": "Bislol",
    "এনজিলক": "Angilock",
    "রোসুভা": "Rosuva",
    "কোরালক্যাল": "Coralcal",
    "কোরালক্যাল ডি": "Coralcal-D",
    "ক্যালবো ডি": "Calbo-D",
    "বেক্সট্রাম গোল্ড": "Bextram Gold",
    "ফিলওয়েল গোল্ড": "Filwel Gold",
    "নিউরো বি": "Neuro-B",
    "স্যালাইন": "SMC ORSaline-N",
    "বার্নসিল": "Burnsil",
    "ডার্মাসল": "Dermasol",
    "পেভিসন": "Pevisone",
}

BANGLA_DIGITS_TRANS = str.maketrans("০১২৩৪৫৬৭৮৯", "0123456789")

QUANTITY_WORDS_BN = {
    "এক": 1, "দুই": 2, "তিন": 3, "চার": 4, "পাঁচ": 5, "ছয়": 6, "সাত": 7, "আট": 8, "নয়": 9, "দশ": 10,
    "এগারো": 11, "বারো": 12, "তেরো": 13, "চৌদ্দ": 14, "পনেরো": 15, "বিশ": 20, "ত্রিশ": 30, "চল্লিশ": 40, "পঞ্চাশ": 50,
    "একশ": 100, "একশো": 100,
}


def parse_voice_command_bangla_english(text: str) -> Tuple[str, int]:
    """
    Intelligently extracts (medicine_query, quantity) from spoken Bangla / English.
    Distinguishes dosage strength (e.g. 20, 500) from quantity (e.g. 10ta, 2 pata, 5 pcs).
    """
    raw = text.strip()
    if not raw:
        return "", 1

    # Convert Bangla digits to standard digits
    text_normalized = raw.translate(BANGLA_DIGITS_TRANS)
    
    extracted_qty = 1
    found_qty = False

    # 1. Look for explicit quantity patterns with suffix (e.g. 10 ta, 20 pcs, 2 pata, 1 strip, 1 box)
    qty_suffix_match = re.search(r'(\d+)\s*(টা|টি|পিস|pcs|পাতা|স্ট্রিপ|strip|বক্স|box|বটম|ফাইল)', text_normalized, re.IGNORECASE)
    if qty_suffix_match:
        qty_num = int(qty_suffix_match.group(1))
        unit = qty_suffix_match.group(2).lower()
        multiplier = 10 if unit in ("পাতা", "স্ট্রিপ", "strip") else (100 if unit in ("বক্স", "box") else 1)
        extracted_qty = max(1, qty_num * multiplier)
        found_qty = True
        # Remove matched quantity segment from search query
        query_text = text_normalized[:qty_suffix_match.start()] + " " + text_normalized[qty_suffix_match.end():]
    else:
        # 2. Look for word quantity (e.g. 'দশটা', 'এক পাতা', 'বিশ পিস')
        query_text = text_normalized
        for w_bn, val in QUANTITY_WORDS_BN.items():
            pattern = rf'\b{w_bn}\s*(টা|টি|পিস|পাতা|স্ট্রিপ|বক্স)?\b'
            if re.search(pattern, query_text):
                multiplier = 10 if "পাতা" in query_text or "স্ট্রিপ" in query_text else 1
                extracted_qty = max(1, val * multiplier)
                found_qty = True
                query_text = re.sub(pattern, '', query_text).strip()
                break

    # 3. Clean query string
    cleaned_query = re.sub(r'\b(দাও|এড কর|এড করুন|এড করো|এড|যোগ কর|দিয়ে দেন|give|add|please|take|cart)\b', '', query_text, flags=re.IGNORECASE).strip()
    cleaned_query = re.sub(r'[^\w\s\-\+\.]', '', cleaned_query).strip()

    # 4. Check phonetic dictionary for known Bangla names
    for bn_key, eng_val in BANGLA_TO_ENG_PHONETIC.items():
        if bn_key in raw or bn_key in cleaned_query:
            cleaned_query = eng_val
            break

    return cleaned_query or text_normalized, max(1, extracted_qty)


@require_POST
def voice_add_to_cart_htmx(request):
    """
    Processes incoming voice audio transcript, adds medicine batch to cart,
    and returns updated cart HTML with speech feedback.
    """
    transcript = request.POST.get("transcript", "").strip()
    if not transcript:
        return HttpResponse("<div class='p-2 text-amber-400'>কোন ভয়েস ইনপুট পাওয়া যায়নি।</div>", status=400)

    drug_query, quantity = parse_voice_command_bangla_english(transcript)
    if not drug_query:
        drug_query = transcript

    tenant_id = getattr(request, "tenant", None)
    tenant_key = str(tenant_id.id) if tenant_id and hasattr(tenant_id, "id") else "default_tenant"

    # Search in cache & DB
    search_results = DrugSearchAndCacheService.search_drugs(query=drug_query, tenant_id=tenant_key, limit=5)
    
    if not search_results:
        # Fallback to fuzzy brand search
        first_word = drug_query.split()[0] if drug_query.split() else drug_query
        db_drug = BrandDrug.objects.filter(
            Q(brand_name__icontains=drug_query) | Q(brand_name__icontains=first_word) | Q(brand_name_bn__icontains=drug_query),
            is_active=True
        ).first()

        if db_drug:
            fefo_batch = db_drug.batches.fefo().first()
            if fefo_batch:
                search_results = [{
                    "id": str(db_drug.id),
                    "brand_name": db_drug.brand_name,
                    "fefo_batch": {"id": str(fefo_batch.id), "current_stock": fefo_batch.current_stock}
                }]

    if not search_results or not search_results[0].get("fefo_batch"):
        return HttpResponse(
            f"""<div class="p-3 bg-rose-900/60 border border-rose-500 rounded-xl text-rose-200 text-xs flex items-center justify-between">
                <span>❌ "{drug_query}" ঔষধটি ডাটাবেসে পাওয়া যায়নি বা পর্যাপ্ত স্টক নেই।</span>
            </div>""",
            status=404
        )

    matched_drug = search_results[0]
    batch_id = matched_drug["fefo_batch"]["id"]

    # Add to Cart
    cart_manager = get_cart_manager(request)
    cart = cart_manager.add_item(batch_id=batch_id, quantity=quantity)

    # Return updated partial + audio speech feedback
    context = {
        "cart": cart,
        "voice_success": {
            "medicine": matched_drug["brand_name"],
            "quantity": quantity,
            "transcript": transcript,
        }
    }
    return render(request, "pos/partials/cart_table.html", context)

