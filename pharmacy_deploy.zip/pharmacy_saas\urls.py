from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render

def landing_view(request):
    """Renders the SaaS marketing landing page."""
    return render(request, "landing.html")

urlpatterns = [
    path("admin/", admin.site.urls),
    path("pos/", include("pos.urls", namespace="pos")),
    path("ledger/", include("core.ledger_urls", namespace="ledger")),
    path("", landing_view, name="landing"),
]
