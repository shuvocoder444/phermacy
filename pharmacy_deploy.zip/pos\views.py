import json
from decimal import Decimal
from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_http_methods, require_GET, require_POST
from django.contrib.auth.decorators import login_required
from django.utils import timezone

from inventory.models import BrandDrug, DrugBatch
from inventory.services import DrugSearchAndCacheService
from customers.models import Customer, DueLedger
from .models import Invoice, CashRegisterSession
from .cart import POSCartManager
from .services import POSCheckoutService, ThermalReceiptGenerator
from notifications.sms_services import BangladeshSMSGateway


def get_cart_manager(request) -> POSCartManager:
    """Helper to retrieve or initialize tenant-scoped Redis cart."""
    if not request.session.session_key:
        request.session.create()
    tenant_id = getattr(request, "tenant", None)
    tenant_key = str(tenant_id.id) if tenant_id and hasattr(tenant_id, "id") else "default_tenant"
    return POSCartManager(session_key=request.session.session_key, tenant_id=tenant_key)


def pos_screen_view(request):
    """
    Main Point-of-Sale terminal view.
    Renders the lightning-fast single screen layout with Alpine.js keyboard listeners.
    """
    cart_manager = get_cart_manager(request)
    cart = cart_manager.get_cart_summary()
    
    tenant_id = getattr(request, "tenant", None)
    tenant_key = str(tenant_id.id) if tenant_id and hasattr(tenant_id, "id") else "default_tenant"
    
    # Pre-prime top drugs in background/cache if empty
    DrugSearchAndCacheService.prime_top_drugs_cache(tenant_id=tenant_key, limit=100)
    
    context = {
        "cart": cart,
        "today": timezone.now().date(),
        "store_name": getattr(tenant_id, "name", "Popular Pharmacy & Care"),
        "store_phone": getattr(tenant_id, "phone", "01711-000000"),
    }
    return render(request, "pos/pos.html", context)


@require_GET
def drug_search_htmx(request):
    """
    HTMX live search endpoint returning matched generic and brand products with FEFO batch stock.
    Triggered instantly on keyup (F2 / search box).
    """
    query = request.GET.get("q", "").strip()
    tenant_id = getattr(request, "tenant", None)
    tenant_key = str(tenant_id.id) if tenant_id and hasattr(tenant_id, "id") else "default_tenant"

    results = DrugSearchAndCacheService.search_drugs(query=query, tenant_id=tenant_key, limit=12)
    
    context = {
        "results": results,
        "query": query,
    }
    return render(request, "pos/partials/search_results.html", context)


@require_POST
def cart_add_htmx(request):
    """
    HTMX endpoint to add a medicine batch to the Redis cart.
    """
    batch_id = request.POST.get("batch_id")
    quantity = int(request.POST.get("quantity", 1))
    
    cart_manager = get_cart_manager(request)
    try:
        cart = cart_manager.add_item(batch_id=batch_id, quantity=quantity)
    except Exception as e:
        return HttpResponse(f"<div class='p-2 text-red-600 font-semibold'>Error: {str(e)}</div>", status=400)

    context = {"cart": cart}
    return render(request, "pos/partials/cart_table.html", context)


@require_POST
def cart_update_quantity_htmx(request):
    """
    HTMX endpoint to increment/decrement/set quantity for a specific batch in cart.
    """
    batch_id = request.POST.get("batch_id")
    quantity = int(request.POST.get("quantity", 1))
    
    cart_manager = get_cart_manager(request)
    cart = cart_manager.update_quantity(batch_id=batch_id, quantity=quantity)
    
    context = {"cart": cart}
    return render(request, "pos/partials/cart_table.html", context)


@require_POST
def cart_remove_item_htmx(request):
    """
    HTMX endpoint to delete an item row from the cart.
    """
    batch_id = request.POST.get("batch_id")
    cart_manager = get_cart_manager(request)
    cart = cart_manager.remove_item(batch_id=batch_id)
    
    context = {"cart": cart}
    return render(request, "pos/partials/cart_table.html", context)


@require_POST
def cart_apply_discount_htmx(request):
    """
    HTMX endpoint to apply percentage or flat discount (F4 shortcut).
    """
    cart_manager = get_cart_manager(request)
    disc_percent = Decimal(request.POST.get("discount_percent", "0.00") or "0.00")
    disc_flat = Decimal(request.POST.get("discount_flat", "0.00") or "0.00")
    
    cart = cart_manager.set_discount(discount_percent=disc_percent, discount_flat=disc_flat)
    context = {"cart": cart}
    return render(request, "pos/partials/cart_table.html", context)


@require_POST
def cart_clear_htmx(request):
    """
    Clears the current active cart.
    """
    cart_manager = get_cart_manager(request)
    cart_manager.clear()
    cart = cart_manager.get_cart_summary()
    return render(request, "pos/partials/cart_table.html", {"cart": cart})


@require_GET
def checkout_modal_htmx(request):
    """
    Renders the checkout tender modal with payment methods (Cash, bKash, Nagad, Rocket, Due).
    """
    cart_manager = get_cart_manager(request)
    cart = cart_manager.get_cart_summary()
    
    # Search or pass customer
    customer_phone = request.GET.get("phone", "").strip()
    customer = None
    if customer_phone:
        customer = Customer.objects.filter(phone=customer_phone).first()

    context = {
        "cart": cart,
        "customer": customer,
        "total_payable": cart["total_payable"],
    }
    return render(request, "pos/partials/checkout_modal.html", context)


@require_POST
def checkout_submit_htmx(request):
    """
    Executes the final sale checkout, writes invoice, deducts FEFO stock,
    and returns receipt modal with auto-print script.
    """
    cart_manager = get_cart_manager(request)
    
    payment_method = request.POST.get("payment_method", "CASH")
    paid_amount = Decimal(request.POST.get("paid_amount", "0.00") or "0.00")
    customer_id = request.POST.get("customer_id") or None
    customer_name = request.POST.get("customer_name", "Walk-in Customer")
    customer_phone = request.POST.get("customer_phone", "").strip()
    gateway_trx_id = request.POST.get("gateway_trx_id", "").strip()
    doctor_name = request.POST.get("doctor_name", "").strip()

    # Cashier
    cashier = request.user if request.user.is_authenticated else None
    if not cashier:
        from django.contrib.auth.models import User
        cashier, _ = User.objects.get_or_create(username="cashier_demo", defaults={"first_name": "Demo Cashier"})

    try:
        invoice, summary = POSCheckoutService.process_checkout(
            cart_manager=cart_manager,
            cashier=cashier,
            payment_method=payment_method,
            paid_amount=paid_amount,
            customer_id=customer_id,
            customer_name=customer_name,
            customer_phone=customer_phone,
            gateway_trx_id=gateway_trx_id,
            doctor_name=doctor_name,
        )

        # Dispatch optional SMS confirmation
        if customer_phone:
            tenant_name = getattr(request.tenant, "name", "Pharmacy Care") if hasattr(request, "tenant") else "Pharmacy Care"
            BangladeshSMSGateway.send_invoice_sms(
                customer_phone=customer_phone,
                invoice_number=invoice.invoice_number,
                total_payable=str(invoice.total_payable),
                due_amount=str(invoice.due_amount),
                pharmacy_name=tenant_name,
            )

        context = {
            "invoice": invoice,
            "items": invoice.items.select_related("drug", "batch").all(),
            "summary": summary,
        }
        return render(request, "pos/partials/receipt_modal.html", context)

    except Exception as e:
        return HttpResponse(
            f"""<div class="p-4 bg-red-100 border-l-4 border-red-500 text-red-700">
                <p class="font-bold">Checkout Error</p>
                <p>{str(e)}</p>
            </div>""",
            status=400
        )


@require_GET
def print_thermal_receipt(request, invoice_id):
    """
    Renders the dedicated 80mm/58mm thermal receipt page for browser or ESC/POS print dialog.
    """
    invoice = get_object_or_404(Invoice.objects.select_related("cashier", "customer"), id=invoice_id)
    items = invoice.items.select_related("drug", "batch").all()
    
    tenant = getattr(request, "tenant", None)
    store_name = getattr(tenant, "name", "Popular Pharmacy & Health Care")
    store_phone = getattr(tenant, "phone", "01712-345678")
    store_address = getattr(tenant, "address", "Dhanmondi, Dhaka-1209")
    vat_reg = getattr(tenant, "vat_reg_number", "BIN-123456789")

    context = {
        "invoice": invoice,
        "items": items,
        "store_name": store_name,
        "store_phone": store_phone,
        "store_address": store_address,
        "vat_reg": vat_reg,
    }
    return render(request, "pos/thermal_receipt_80mm.html", context)

